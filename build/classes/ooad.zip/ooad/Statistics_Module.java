package ooad;

public abstract class Statistics_Module {
     public abstract void draw();
}
