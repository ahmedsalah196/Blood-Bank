
package ooad;
import java.util.*;
import java.text.*;

import javax.swing.JOptionPane;


public class blood {
    private final String blood_type;
    private float blood_amount=0;
    private final float critical_point;
    private ArrayList<DateAndAmount> history =new ArrayList<DateAndAmount>();
    public static Map allBlood=new HashMap();
    public blood(String blood_type, float blood_amount, float critical_point) {
        this.blood_type = blood_type;
        this.blood_amount = blood_amount;
        this.critical_point = critical_point;
    }
    public void requestBlood(){
            JOptionPane.showMessageDialog(null, "blooad amount of "+blood_type +" below critical", "CRITICAL SITUATION", JOptionPane.WARNING_MESSAGE);
    }
    public void adjustAmount(float n){
        if(blood_amount+n<0)JOptionPane.showMessageDialog(null, "Can't afford your request because the blood Amount of "+blood_type+" is "+blood_amount, "Insufficient Amount", JOptionPane.WARNING_MESSAGE);
        else blood_amount+=n;
        if(allBlood.containsKey(blood_type)) allBlood.replace(blood_type, blood_amount);
        else allBlood.put(blood_type, blood_amount);
        if (blood_amount<=critical_point) requestBlood();
        history.add(new DateAndAmount(new Date(), blood_amount));
    }
    public String getType(){
         return blood_type;
    }
}
class DateAndAmount{
  public Date currentDate;
  public float amount;

    public DateAndAmount(Date currentDate, float amount) {
        this.currentDate = currentDate;
        this.amount = amount;
    }
  
}