package ooad;

public class Oneg extends blood {
    
    public Oneg(String blood_type, float blood_amount, float critical_point) {
super("O-",0,critical_point);   
    }
    
}