package ooad;

public class Aneg extends blood {  
    public Aneg(String blood_type, float blood_amount, float critical_point) {
        super("A-",0,critical_point);
    }
}