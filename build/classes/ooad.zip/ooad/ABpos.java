package ooad;

public class ABpos extends blood {
    
    public ABpos(String blood_type, float blood_amount, float critical_point) {
        super("AB+",0,critical_point);
    }
    
}