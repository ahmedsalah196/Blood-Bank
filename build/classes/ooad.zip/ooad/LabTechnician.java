
package ooad;
import java.util.*;
public class LabTechnician {
private String ID,Password;
private static boolean newPacks=false;
public static ArrayList<bloodpack> packsToDo=new ArrayList();
public LabTechnician(String ID, String Password) {
        this.ID = ID;
        this.Password = Password;
    }
private int find(String code){
    for (int i=0;i<packsToDo.size();i++) {
        if(packsToDo.get(i).getBarcode().equals(code))
            return i;
    }
    return -1;
}
public void extract(String code){
    bloodpack bp=packsToDo.get(find(code));
    int extractedAmount=0;
    String extrctedType=null;
    boolean accepted=false;
    if(accepted){
    bp.setAmount(extractedAmount);
    bp.setType(extrctedType);
    bloodpack.accepted++;
    }
    else bloodpack.rejected++;
    packsToDo.remove(find(bp.getBarcode()));
    bp.add();
}
public boolean login(String ID,String Password){
    if(this.ID.equals(ID)&&this.Password.equals(Password)) return true;
    else return false;
}

    public static void setNewPacks(boolean newPacks) {
        LabTechnician.newPacks = newPacks;
    }

}
