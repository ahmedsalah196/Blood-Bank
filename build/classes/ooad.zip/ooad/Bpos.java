package ooad;

public class Bpos extends blood {
    
    public Bpos(String blood_type, float blood_amount, float critical_point) {
super("B+",0,critical_point);
    }
    
}