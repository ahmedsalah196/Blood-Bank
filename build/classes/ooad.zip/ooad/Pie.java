
package ooad;


public class Pie extends Statistics_Module{

    @Override
    public void draw() {
        //to be implemented
    }
    
}
