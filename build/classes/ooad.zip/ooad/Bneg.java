package ooad;

public class Bneg extends blood {
    
    public Bneg(String blood_type, float blood_amount, float critical_point) {
        super("B-",0,critical_point);
    }
    
}