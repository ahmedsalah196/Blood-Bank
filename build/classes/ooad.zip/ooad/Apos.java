
package ooad;

public class Apos extends blood {
    
    public Apos(String blood_type, float blood_amount, float critical_point) {
        super("A+",0,critical_point);
    }
    
}
