
package ooad;


public class line extends Statistics_Module{

    @Override
    public void draw() {
        //to be implemented
    }
    
}
