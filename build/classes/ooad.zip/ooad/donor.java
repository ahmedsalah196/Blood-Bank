
package ooad;
import java.util.Date;
import javax.swing.JOptionPane;

public class donor {
public String ID;
public blood b;
private Date lastDonation;

public donor(String i , blood b){
    this.ID = i;
    this.b = b;
    
}

public Boolean checkLastDonation(Date d1){
    Date d2 = new Date(lastDonation.getYear(),lastDonation.getMonth(),lastDonation.getDay()+56);
    if(d1.compareTo(d2)>=0){
        lastDonation=d2;
     return true;   
    }
    else return false;
    
}

public void setLastDonationDate(Date d1){
    this.lastDonation = d1;
}
public void sendPack(){
    if(checkLastDonation(new Date())){
    LabTechnician.packsToDo.add(new bloodpack(this.ID,""+bloodpack.bloodpacksId++,new Date()));
    LabTechnician.setNewPacks(true);
    }
    else JOptionPane.showMessageDialog(null, "You can't Donate Now", "Too Early", 0);
}
}