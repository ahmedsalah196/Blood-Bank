package ooad;

public class ABneg extends blood {
    
    public ABneg( float critical_point) {
        super("AB-",0,critical_point);
    }
    
}
