package ooad;
import java.util.Date;
import java.util.*;
public class bloodpack {
    public static ArrayList<bloodpack> bloodpacks=new ArrayList();
    public static int accepted=0,rejected=0,bloodpacksId=1;
    boolean verified;
    private String BloodType=null;
    private String donorID;
    private String Barcode;
    private Date dateExtracted;
    private float amount;
    public bloodpack(String id , String code , Date d1 ){
        this.donorID = id;
        this.Barcode = code;
        this.dateExtracted = d1;
    }

    public void setType(String type){
        this.BloodType=type;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }
    public void add(){
        bloodpacks.add(this);
    }

    public String getBarcode() {
        return Barcode;
    }
    
}
