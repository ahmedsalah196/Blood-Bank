package ooad;

import javafx.event.ActionEvent;

public abstract class Statistics_Module {
     public abstract void draw(ActionEvent even) throws Exception;
}
