package ooad;

public class Opos extends blood {
    
    public Opos() {
        super("O+",1000,300);
    }
}