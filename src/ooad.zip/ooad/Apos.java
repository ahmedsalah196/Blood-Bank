
package ooad;

public class Apos extends blood {
    
    public Apos() {
        super("A+",2500,1000);
    }
    
}
