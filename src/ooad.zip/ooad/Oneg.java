package ooad;

public class Oneg extends blood {
    
    public Oneg() {
super("O-",500,100);   
    }
    
}