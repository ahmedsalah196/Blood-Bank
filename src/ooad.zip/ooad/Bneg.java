package ooad;

public class Bneg extends blood {
    
    public Bneg() {
        super("B-",1500,700);
    }
    
}