package ooad;

public class ABneg extends blood {
    
    public ABneg() {
        super("AB-",700,200);
    }
    
}
