package ooad;

public class ABpos extends blood {
    
    public ABpos() {
        super("AB+",800,300);
    }
    
}