package ooad;

public class Aneg extends blood {  
    public Aneg() {
        super("A-",2000,700);
    }
}