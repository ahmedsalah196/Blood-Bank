package ooad;

public class Bpos extends blood {
    
    public Bpos() {
        super("B+",2000,500);
    }
    
}